import subprocess

process1 = subprocess.Popen("dotnet neo-cli.dll", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
#process1 = subprocess.Popen("ls", shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
# print process1.communicate()[0]
while True:
    line = process1.stdout.readline()
    if not line:
        continue
    print("sssssssssssssss")
    print(line)
    process1.stdin.write("version\n")
